import 'package:flutter/material.dart';

void main() {
  runApp(const AiAmoz());
}

class AiAmoz extends StatelessWidget {
  const AiAmoz({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'AI Amoz',
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(title: const Text('AI Amoz')),
        body: const Center(
          child: Text('ساخت تصویر با هوش مصنوعی'),
        ),
      ),
    );
  }
}