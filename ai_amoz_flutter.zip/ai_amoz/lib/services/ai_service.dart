class AiService {
  // API connection will be added here.
}